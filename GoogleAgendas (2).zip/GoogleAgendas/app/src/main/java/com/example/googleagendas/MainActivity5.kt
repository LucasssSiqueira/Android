package com.example.googleagendas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)

        val exercicio: String = intent.getStringExtra("exercicio")!!

        val semana1: TextView = findViewById(R.id.txt_onceweek)
        semana1.setOnClickListener{
            abrirTime("uma vez por semana")
        }

    }

     fun abrirTime(frequencia: String) {
         startActivity(
             Intent(this, MainActivity6::class.java)
                 .putExtra("frequencia", frequencia)

         )

    }
}