package com.example.googleagendas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textViewexercise: TextView = findViewById(R.id.title_exercise)
        textViewexercise.setOnClickListener{
            irActivity2()
        }
    }

    fun irActivity2(){
           val abrir_exercicio = Intent(this, MainActivityTela2::class.java)
        startActivity(abrir_exercicio)

    }
}


