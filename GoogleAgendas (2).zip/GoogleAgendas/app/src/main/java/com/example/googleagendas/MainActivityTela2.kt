package com.example.googleagendas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivityTela2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_tela2)

       val txt_workout: TextView = findViewById(R.id.txt_onceweek)
        txt_workout.setOnClickListener{
            abrirTela3("malhar")
        }

        val txt_run: TextView = findViewById(R.id.textViewThreeTimes)
        txt_run.setOnClickListener{
            abrirTela3("run")
        }

        val txt_yoga: TextView = findViewById(R.id.textViewEveryday)
        txt_yoga.setOnClickListener{
            abrirTela3("yoga")
        }
    }

     fun abrirTela3(exercicioEscolhido: String) {
    startActivity(
        Intent(this, MainActivity3::class.java)
            .putExtra("exercicio", exercicioEscolhido )
    )

    }

}